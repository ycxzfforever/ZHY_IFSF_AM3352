#!/bin/sh
###############ycx add######################                          
echo "Starting jksoft..."  
set_addr.sh                                                           
get_time.sh                                      
mkdir -p /var/spool/cron/crontabs           
mkdir -p /home/root                                        
cron&                                         
crontab /etc/mycrontab                      
sleep 5                                                      
jkmonitor.sh&
###############ycx endadd###################

